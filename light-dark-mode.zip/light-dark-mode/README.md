# Light/Dark Mode

A Pen created on CodePen.io. Original URL: [https://codepen.io/Dirgha-M/pen/MWNNzjx](https://codepen.io/Dirgha-M/pen/MWNNzjx).

